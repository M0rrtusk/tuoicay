package com.example.tuoicayiot;

// Thư viện Android UI và Core
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.view.View;
import android.content.Intent; // Cần thiết để chuyển Activity

// Thư viện cho HashMap (Cấu trúc dữ liệu)
import java.util.HashMap;

// Thư viện Firebase
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DatabaseError;


public class RegisterActivity extends AppCompatActivity {

    EditText etUsername, etPassword;
    Button btnRegister, btnMoveLogin; // <<< Khai báo thêm nút mới
    DatabaseReference db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnRegister = findViewById(R.id.btnRegister);
        btnMoveLogin = findViewById(R.id.btnMoveLogin); // <<< Tham chiếu ID

        db = FirebaseDatabase.getInstance().getReference("users");

        // <<< Cài đặt sự kiện click cho nút Quay lại Đăng nhập
        btnMoveLogin.setOnClickListener(v -> {
            // Sử dụng finish() sẽ đóng RegisterActivity và quay lại LoginActivity (vì LoginActivity đã gọi nó)
            // Nếu bạn muốn chắc chắn, bạn có thể gọi Intent:
            // startActivity(new Intent(this, LoginActivity.class));
            finish();
        });

        btnRegister.setOnClickListener(v -> {
            String user = etUsername.getText().toString().trim();
            String pass = etPassword.getText().toString().trim();

            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Không để trống!", Toast.LENGTH_SHORT).show();
                return;
            }

            db.child(user).get().addOnCompleteListener(task -> {
                if (task.getResult().exists()) {
                    Toast.makeText(this, "Username đã tồn tại!", Toast.LENGTH_SHORT).show();
                } else {
                    HashMap<String, Object> data = new HashMap<>();
                    data.put("password", pass);
                    data.put("role", "user");

                    db.child(user).setValue(data).addOnSuccessListener(a -> {
                        Toast.makeText(this, "Đăng ký thành công", Toast.LENGTH_SHORT).show();
                        // Quay lại màn hình đăng nhập sau khi đăng ký thành công
                        finish();
                    });
                }
            });
        });
    }
}