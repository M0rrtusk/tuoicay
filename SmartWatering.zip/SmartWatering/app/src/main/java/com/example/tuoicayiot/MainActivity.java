package com.example.tuoicayiot;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private TextView tvMoisture, tvHumidity, tvTemperature, tvPumpStatus, tvMode;
    private EditText etThreshold;
    private Button btnSetThreshold, btnPumpOn, btnPumpOff, btnAuto, btnManual;

    private DatabaseReference dbRef;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FirebaseDatabase db = FirebaseDatabase.getInstance(
                "https://smartwatering-7f76b-default-rtdb.asia-southeast1.firebasedatabase.app/"
        );

        dbRef = db.getReference("SmartWatering");

        tvMoisture = findViewById(R.id.tvMoisture);
        tvHumidity = findViewById(R.id.tvHumidity);
        tvTemperature = findViewById(R.id.tvTemperature);
        tvPumpStatus = findViewById(R.id.tvStatus);
        tvMode = findViewById(R.id.tvMode);

        etThreshold = findViewById(R.id.etThreshold);
        btnSetThreshold = findViewById(R.id.btnSetThreshold);

        btnPumpOn = findViewById(R.id.btnOn);
        btnPumpOff = findViewById(R.id.btnOff);

        btnAuto = findViewById(R.id.btnAuto);
        btnManual = findViewById(R.id.btnManual);

        dbRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot snapshot) {

                if (snapshot.child("moisture").exists()) {
                    Integer moisture = snapshot.child("moisture").getValue(Integer.class);
                    if (moisture != null) {
                        tvMoisture.setText("Độ ẩm đất: " + moisture + "%");
                    }
                }

                if (snapshot.child("humidity").exists()) {
                    Float humidity = snapshot.child("humidity").getValue(Float.class);
                    if (humidity != null) {
                        tvHumidity.setText("Độ ẩm không khí: " + humidity + "%");
                    }
                }

                if (snapshot.child("temperature").exists()) {
                    Float temp = snapshot.child("temperature").getValue(Float.class);
                    if (temp != null) {
                        tvTemperature.setText("Nhiệt độ: " + temp + "°C");
                    }
                }

                if (snapshot.child("status").exists()) {
                    String status = snapshot.child("status").getValue(String.class);
                    if (status != null) {
                        tvPumpStatus.setText("Trạng thái bơm: " + status);
                    }
                }

                if (snapshot.child("controlMode").exists()) {
                    Integer mode = snapshot.child("controlMode").getValue(Integer.class);
                    if (mode != null) {
                        tvMode.setText("Chế độ: " + (mode == 1 ? "TỰ ĐỘNG" : "THỦ CÔNG"));
                    }
                }

                if (snapshot.child("threshold").exists()) {
                    Integer th = snapshot.child("threshold").getValue(Integer.class);
                    if (th != null) {
                        etThreshold.setText(String.valueOf(th));
                    }
                }
            }

            @Override
            public void onCancelled(DatabaseError error) {
                Log.d("FIREBASE", "Error: " + error.getMessage());
            }
        });

        btnPumpOn.setOnClickListener(v -> {
            dbRef.child("pump").setValue(2); // ESP32 hiểu 2 = ON
            Toast.makeText(this, "Đã gửi lệnh BẬT bơm", Toast.LENGTH_SHORT).show();
        });

        btnPumpOff.setOnClickListener(v -> {
            dbRef.child("pump").setValue(0); // ESP32 hiểu 0 = OFF
            Toast.makeText(this, "Đã gửi lệnh TẮT bơm", Toast.LENGTH_SHORT).show();
        });

        btnSetThreshold.setOnClickListener(v -> {
            String value = etThreshold.getText().toString().trim();
            if (value.isEmpty()) {
                Toast.makeText(this, "Nhập ngưỡng!", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                int threshold = Integer.parseInt(value);
                if (threshold < 5 || threshold > 95) {
                    Toast.makeText(this, "Ngưỡng phải từ 5-95%", Toast.LENGTH_SHORT).show();
                    return;
                }

                dbRef.child("threshold").setValue(threshold);
                Toast.makeText(this, "Đã cập nhật ngưỡng!", Toast.LENGTH_SHORT).show();
            } catch (NumberFormatException e) {
                Toast.makeText(this, "Ngưỡng không hợp lệ!", Toast.LENGTH_SHORT).show();
            }
        });

        btnAuto.setOnClickListener(v -> {
            dbRef.child("controlMode").setValue(1);
            Toast.makeText(this, "Đang bật chế độ TỰ ĐỘNG", Toast.LENGTH_SHORT).show();
        });

        btnManual.setOnClickListener(v -> {
            dbRef.child("controlMode").setValue(0);
            Toast.makeText(this, "Đang dùng chế độ THỦ CÔNG", Toast.LENGTH_SHORT).show();
        });
    }
}