package com.example.tuoicayiot;

import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";

    TextView txtMoisture, txtStatus;
    Button btnOn, btnOff;

    DatabaseReference database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Ánh xạ view
        txtMoisture = findViewById(R.id.txtMoisture);
        txtStatus = findViewById(R.id.txtStatus);
        btnOn = findViewById(R.id.btnOn);
        btnOff = findViewById(R.id.btnOff);

        // Kết nối node SmartWatering trên Firebase
        database = FirebaseDatabase.getInstance().getReference("SmartWatering");

        // Lắng nghe dữ liệu từ Firebase
        database.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {

                if (snapshot.exists()) {

                    Integer moisture = snapshot.child("moisture").getValue(Integer.class);
                    String status = snapshot.child("status").getValue(String.class);

                    if (moisture != null) {
                        txtMoisture.setText(moisture + " %");
                    } else {
                        txtMoisture.setText("-- %");
                    }

                    if (status != null) {
                        txtStatus.setText(status);
                    } else {
                        txtStatus.setText("UNKNOWN");
                    }

                } else {
                    txtStatus.setText("No data");
                    txtMoisture.setText("-- %");
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Firebase error: " + error.getMessage());
                Toast.makeText(MainActivity.this, "Firebase error!", Toast.LENGTH_SHORT).show();
            }
        });

        // Bật bơm
        btnOn.setOnClickListener(v -> {
            database.child("pump").setValue(1);
            database.child("status").setValue("ON");
            Toast.makeText(this, "Pump ON", Toast.LENGTH_SHORT).show();
        });

        // Tắt bơm
        btnOff.setOnClickListener(v -> {
            database.child("pump").setValue(0);
            database.child("status").setValue("OFF");
            Toast.makeText(this, "Pump OFF", Toast.LENGTH_SHORT).show();
        });
    }
}
