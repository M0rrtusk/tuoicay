package com.example.tuoicayiot;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.Button;
import android.widget.Toast;
import android.content.Intent;
import android.view.View;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;

public class LoginActivity extends AppCompatActivity {

    EditText etUsername, etPassword;

    Button btnLogin, btnMoveRegister;
    DatabaseReference db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        etUsername = findViewById(R.id.etUsername);
        etPassword = findViewById(R.id.etPassword);
        btnLogin = findViewById(R.id.btnLogin);
        btnMoveRegister = findViewById(R.id.btnMoveRegister);

        db = FirebaseDatabase.getInstance().getReference("users");

        btnMoveRegister.setOnClickListener(v ->
                startActivity(new Intent(this, RegisterActivity.class))
        );

        btnLogin.setOnClickListener(v -> {
            String user = etUsername.getText().toString();
            String pass = etPassword.getText().toString();

            if (user.isEmpty() || pass.isEmpty()) {
                Toast.makeText(this, "Điền đủ thông tin!", Toast.LENGTH_SHORT).show();
                return;
            }

            db.child(user).get().addOnCompleteListener(task -> {
                if (!task.getResult().exists()) {
                    Toast.makeText(this, "Sai username!", Toast.LENGTH_SHORT).show();
                } else {
                    String realPass = task.getResult().child("password").getValue(String.class);

                    if (realPass.equals(pass)) {
                        Toast.makeText(this, "Đăng nhập thành công", Toast.LENGTH_SHORT).show();

                        startActivity(new Intent(this, MainActivity.class));
                        finish();
                    } else {
                        Toast.makeText(this, "Sai mật khẩu!", Toast.LENGTH_SHORT).show();
                    }
                }
            });
        });
    }
}
